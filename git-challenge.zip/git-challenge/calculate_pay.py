import sys


def get_perf_pay(readers):
    if readers < 200:
        ret
    if readers <= 400:
        return read
    return 100 + (readers - 400) * 0.03


if __name__ == "__main__":
    if (len(sys.argv)) < 2:
        print('Plea
    else:
        print('Total pay:')
        print(get_perf_pay(int(sys.argv[1])))
